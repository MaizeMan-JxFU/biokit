# from . import base
from .base import *


__name__ = 'Genotype Reader'
__version__ = '1.0'